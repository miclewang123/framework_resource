#include <stdio.h>
#include <string.h>

#include <v8.h>

using namespace v8;

unsigned int age;
char name[128];

//get the value of x variable inside javascript
static v8::Handle<v8::Value> XGetter(v8::Local<v8::String> name, const v8::AccessorInfo& info) {
  return  v8::Number::New(x);
}

//set the value of x variable inside javascript
static void XSetter(v8::Local<v8::String> name,v8::Local<v8::Value> value,const v8::AccessorInfo& info) {
  x = value->Int32Value();
}

//get the value of username variable inside javascript
v8::Handle<v8::Value> userGetter(v8::Local<v8::String> name,const v8::AccessorInfo& info) {
	return v8::String::New((char*)&username,strlen((char*)&username));
}

//set the value of username variable inside javascript
void userSetter(v8::Local<v8::String> name, v8::Local<v8::Value> value,const v8::AccessorInfo& info) {
	v8::Local<v8::String> s = value->ToString();
	s->WriteAscii((char*)&username);
}

//convert unsigned int to value
static v8::Local<v8::Value> v8_uint32(unsigned int x) {
	return v8::Uint32::New(x);
}

int main(int argc, char* argv[]) {
	// Create a stack-allocated handle scope.
	HandleScope handle_scope;

	// Create a new context.
	Persistent<Context> context = Context::New();

	// Enter the created context for compiling and
	// running the hello world script. 
	Context::Scope context_scope(context);

	// Create a string containing the JavaScript source code.
	Handle<String> source =  String::New("(function(a, b){return a * b;})(4, 7);");

	// Compile the source code.
	Handle<Script> script = Script::Compile(source);

	// Run the script to get the result.
	Handle<Value> result = script->Run();

	// Dispose the persistent context.
	context.Dispose();

	// Convert the result to an ASCII string and print it.
	String::AsciiValue ascii(result);

	printf("script result : %s\n", *ascii);

	getchar();

	return 0;
}
