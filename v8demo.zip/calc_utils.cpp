#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <v8.h>

using namespace v8;

const char* ToCString(const String::Utf8Value& value) {
	return *value ? *value : "<string conversion failed>";
}

Handle<Value> Print(const Arguments& args) {
	bool first = true;

	for (int i = 0; i < args.Length(); i++) {
		HandleScope handle_scope;
		if (first) {
			first = false;
		} else {
			printf(" ");
		}
		String::Utf8Value str(args[i]);
		const char* cstr = ToCString(str);
		printf("%s", cstr);
	}

	printf("\n");
	fflush(stdout);

	return Undefined();
}

Handle<Value> Quit(const Arguments& args){
	exit(0);
	return Undefined();
}

extern Handle<String> ReadFile(const char* name);
extern bool ExecuteString(Handle<String> source, Handle<Value> name, bool print_result);

Handle<Value> Load(const Arguments& args){
	if(args.Length() != 1){
		return Undefined();
	}

	HandleScope handle_scope;
	String::Utf8Value file(args[0]);

	Handle<String> source = ReadFile(*file);
	ExecuteString(source, String::New(*file), false);

	return Undefined();
}