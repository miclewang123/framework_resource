#include <stdio.h>
#include <string.h>

#include <v8.h>

using namespace v8;

extern const char* ToCString(const String::Utf8Value& value);

bool ExecuteString(Handle<String> source,
				   Handle<Value> name,
				   bool print_result) 
{
	HandleScope handle_scope;
	TryCatch try_catch;
	Handle<Script> script = Script::Compile(source, name);
	if (script.IsEmpty()) {
		return false;
	} else {
		Handle<Value> result = script->Run();
		if (result.IsEmpty()) {
			return false;
		} else {
			if (print_result && !result->IsUndefined()) {
				v8::String::Utf8Value str(result);
				const char* cstr = ToCString(str);
				printf("%s\n", cstr);
			}
			return true;
		}
	}
}

// Reads a file into a v8 string.
Handle<String> ReadFile(const char* name) {
	FILE* file = fopen(name, "rb");
	if (file == NULL) return Handle<String>();

	fseek(file, 0, SEEK_END);
	int size = ftell(file);
	rewind(file);

	char* chars = new char[size + 1];
	chars[size] = '\0';
	for (int i = 0; i < size;) {
		int read = fread(&chars[i], 1, size - i, file);
		i += read;
	}

	fclose(file);

	Handle<String> result = String::New(chars, size);

	delete[] chars;

	return result;
}
