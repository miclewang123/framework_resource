#include <stdio.h>
#include <string.h>

#include <v8.h>

using namespace v8;

//env
extern bool ExecuteString(Handle<String> source, Handle<Value> name, bool print_result);
extern Handle<String> ReadFile(const char* name);

//utils
extern Handle<Value> Load(const Arguments& args);
extern Handle<Value> Print(const Arguments& args);
extern Handle<Value> Quit(const Arguments& args);

void MainLoop(Handle<Context> context){
	while(true){
		char buffer[1024] = {0};
		printf("$ ");
		char *str = fgets(buffer, sizeof(buffer), stdin);
		if(str == NULL){
			break;
		}
		HandleScope handle_scope;
		ExecuteString(String::New(str), String::New("calc"), true);
	}
}

int main(int argc, char *argv[]){
	HandleScope handle_scope;

	// Create a template for the global object.
	Handle<ObjectTemplate> global = ObjectTemplate::New();

	// Bind the global 'print' function to the C++ Print callback.
	global->Set(String::New("load"), FunctionTemplate::New(Load));
	global->Set(String::New("print"), FunctionTemplate::New(Print));
	global->Set(String::New("quit"), FunctionTemplate::New(Quit));

	// Create a new execution environment containing the built-in
	// functions
	Handle<Context> context = Context::New(NULL, global);

	// Enter the newly created execution environment.
	Context::Scope context_scope(context);
	
	MainLoop(context);

	return 0;
}