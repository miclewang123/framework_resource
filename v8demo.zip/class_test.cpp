#include <stdio.h>
#include <string.h>

#include <v8.h>

using namespace v8;

class Person{
private:
	unsigned int age;
	char name[512];

public:
	Person(unsigned int age, char *name){
		this->age = age;
		strncpy(this->name, name, sizeof(this->name));
	}

	unsigned int getAge(){
		return this->age;
	}

	void setAge(unsigned int nage){
		this->age = nage;
	}

	char *getName(){
		return this->name;
	}

	void setName(char *nname){
		strncpy(this->name, nname, sizeof(this->name));
	}
};

Handle<Value> pgetAge(const Arguments& args){
	Local<Object> self = args.Holder();
	Local<External> wrap = Local<External>::Cast(self->GetInternalField(0));
	void *ptr = wrap->Value();
	unsigned int age = static_case<Person*>(ptr)->getAge();
	return Integer::New(age);
}

Handle<Value> psetAge(const Arguments& args){

}

int main(int argc, char *argv[]){
	Person *person = new Person(26, "juntao");
	
	printf("age : %d, name : %s\n", person->getAge(), person->getName());
	
	person->setAge(27);
	person->setName("juntao.qiu");

	printf("age : %d, name : %s\n", person->getAge(), person->getName());

	Handle<FunctionTemplate> person_template = FunctionTemplate::New();
	person_template->SetClassName(String::New("Person"));

	Handle<ObjectTemplate> person_proto = person_template->PrototypeTemplate();
	
	person_proto->Set("getAge", FunctionTemplate::New(pgetAge));
	person_proto->Set("setAge", FunctionTemplate::New(psetAge));

	person_proto->Set("getName", FunctionTemplate::New(pgetName));
	person_proto->Set("setName", FunctionTemplate::New(psetName));

	Handle<ObjectTemplate> person_inst = person_template->InstanceTemplate();
	person_inst->SetInternalFieldCount(1);

	person_inst->SetAccessor(String::New("age"), GetAge, SetAge);

	delete person;

	getchar();

	return 0;
}