var name='js';
print(name);

var x = (function(a, b){
	return a + b;	
})(12, 7);

print(x);