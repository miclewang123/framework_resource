#include "websocket_respond.h"

Websocket_Respond::Websocket_Respond() { }

Websocket_Respond::~Websocket_Respond() { }
