#include "network_interface.h"

int main(int argc, char **argv){
	NETWORK_INTERFACE->run();
	return 0;
}
