#ifndef _MEVENT_H
#define _MEVENT_H

#define CRLF        "\r\n"

#define SERVER      "mevent"

#endif